eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(q(e){e.7K.1w=q(n){5((5N n).4q("7H|7G")){29 8.1c(q(e){7D t(8,n)})}D{5(n=="7"){j r=e(8).7("2y").g;5(r){29 r}}D{29 8.1c(q(t){j r=e(8).7("2y");5(r){5(!r.g.1U){5(5N n=="7F"){5(n>0&&n<r.g.1z+1&&n!=r.g.1l){r.2G(n)}}D{2s(n){Y"1g":r.o.3G();r.1g("3M");X;Y"1e":r.o.3C();r.1e("3M");X;Y"1h":5(!r.g.1B){r.o.66();r.g.1O=C;r.1h()}X;Y"2E":r.d.4P();X}}}5((r.g.1B||!r.g.1B&&r.g.1O)&&n=="I"){r.o.64();r.g.1O=L;r.g.10.k(\'1n[J*="2W.3a"], 1n[J*="2U.2F"]\').1c(q(){2V(e(8).7("3L"))});r.I()}}})}}};j t=q(n,r){j i=8;i.$5O=e(n).16("4-1J");i.$5O.7("2y",i);i.1D=q(){i.o=e.5T({},t.5E,r);i.g=e.5T({},t.57);5(!i.g.5Z){i.g.5Z=C;i.2E();5(e("3h").k(\'5W[4c*="3F"]\').V){i.g.4t=e("3h").k(\'5W[4c*="3F"]\').F("4c").1i("3F")[1]}5(e("3h").k(\'4y[J*="3T"]\').V){5(e("3h").k(\'4y[J*="3T"]\').F("J").11("?")!=-1){i.g.4x=e("3h").k(\'4y[J*="3T"]\').F("J").1i("?")[1].1i("=")[1]}}i.d.1S("2y 7S");i.d.1V(\'<a 1o="#">1g</a> | <a 1o="#">1e</a> | <a 1o="#">1h</a> | <a 1o="#">I</a> | <a 1o="#">6q I</a>\');i.d.21.k("a").1c(q(){e(8).1p(q(t){t.1I();5(e(8).4i()=="6q I"){e(n).k("*").I(C,L);e(n).1w("I")}D{e(n).1w(e(8).4i())}})});i.d.1S("2y 2z 7U");i.d.1V("7R 2z: <Z>"+i.g.2z+"</Z>");5(i.g.4x){i.d.1A("7Q 2z: <Z>"+i.g.4x+"</Z>")}5(i.g.4t){i.d.1A("3F 2z: <Z>"+i.g.4t+"</Z>")}i.d.1A("6d 2z: <Z>"+e().7N+"</Z>");5(e(n).F("5g")){i.d.1S("2y 1J");i.d.1V("#"+e(n).F("5g"))}i.d.1S("7p 8v");i.d.55();2v(j s 5o i.o){i.d.1A(s+": <Z>"+i.o[s]+"</Z>")}5(!i.o.1x||i.o.1x==""||!i.o.2g||i.o.2g==""){i.d.1S("8e 8b 1x. 89: 6z 1x 6x / 6l 2g.");i.2I()}D{i.d.1S("6M 6V 1D 7g 1x: "+i.o.1x,C);e(n).16("4-"+i.o.1x);j o=i.o.2g+i.o.1x+"/1x.z";4g=e("5S");5(!e("5S").V){4g=e("2M")}5(e(\'3r[1o="\'+o+\'"]\').V){i.d.1V(\'8w "\'+i.o.1x+\'" 2r 6v 2x.\');u=e(\'3r[1o="\'+o+\'"]\')}D{5(3V.6c){3V.6c(o);j u=e(\'3r[1o="\'+o+\'"]\')}D{j u=e(\'<3r 3J="6C" 1o="\'+o+\'" 5i="4i/z" />\').Q(4g)}}u.1D(q(){5(!i.g.2x){i.d.1V("6j.1D(); 4f");i.g.2x=C;i.2I()}});e(22).1D(q(){5(!i.g.2x){i.d.1V("$(22).1D(); 4f");i.g.2x=C;i.2I()}});2w(q(){5(!i.g.2x){i.d.1S("77 7f: 7h 6j.1D(); 6l $(22).1D(); 6D 4f");i.g.2x=C;i.2I()}},6N)}}};i.2I=q(){i.d.1S("6I 4.2I();");i.d.55();i.g.14=q(){29 e(n).B()};i.g.19=q(){29 e(n).H()};5(e(n).k(".4-1a").V==1){i.o.42=L;i.o.4V=L;i.o.3X=L;i.o.3K=L;i.o.2b=0;i.o.43=L;i.o.27=C;i.o.1j=1;i.o.1G="6K"}i.d.1A("72 6J 6H 6y: <Z>"+e(n).k(".4-1a").V+"</Z>");5(i.o.B){i.g.4d=i.g.1t=""+i.o.B}D{i.g.4d=i.g.1t=e(n)[0].1u.B}i.d.1A("1t: <Z>"+i.g.1t+"</Z>");5(i.o.H){i.g.1T=""+i.o.H}D{i.g.1T=e(n)[0].1u.H}i.d.1A("1T: <Z>"+i.g.1T+"</Z>");5(i.g.1t.11("%")==-1&&i.g.1t.11("17")==-1){i.g.1t+="17"}5(i.g.1T.11("%")==-1&&i.g.1T.11("17")==-1){i.g.1T+="17"}5(i.o.5U&&i.g.1t.11("17")!=-1&&i.g.1T.11("17")!=-1){i.g.2d=C}D{i.g.2d=L}e(n).k(\'*[M*="4-s"], *[M*="4-2m"]\').1c(q(){5(!e(8).1y().3d("4-1a")){e(8).6A(e(8).1y())}});e(n).k(".4-1a").1c(q(){e(8).1E(\':63([M*="4-"])\').1c(q(){e(8).4O()})});i.d.1S("2y 6E");e(n).k(\'.4-1a, *[M*="4-s"]\').1c(q(){5(e(8).3d("4-1a")){i.d.1V("<Z>5l "+(e(8).2t()+1)+"</Z>");i.d.4T();i.d.1A("<Z>5l "+(e(8).2t()+1)+" 5j:</Z><3O><3O>")}D{i.d.1V("    79 "+(e(8).2t()+1));i.d.5M(e(8));i.d.4T();i.d.1A("<Z>7b "+(e(8).2t()+1)+" 5j:</Z><3O><3O>");i.d.1A("5i: <Z>"+e(8).1g().76("75")+"</Z>");i.d.1A("M: <Z>"+e(8).F("M")+"</Z>")}5(e(8).F("3J")||e(8).F("1u")){5(e(8).F("3J")){j t=e(8).F("3J").3e().1i(";")}D{j t=e(8).F("1u").3e().1i(";")}2v(x=0;x<t.V;x++){1C=t[x].1i(":");5(1C[0].11("6W")!=-1){1C[1]=i.5c(1C[1])}j n="";5(1C[2]){n=":"+e.2i(1C[2])}5(1C[0]!=" "&&1C[0]!=""){e(8).7(e.2i(1C[0]),e.2i(1C[1])+n);i.d.1A(e.2i(1C[0])+": <Z>"+e.2i(1C[1])+n+"</Z>")}}}j r=e(8);r.7("26",r[0].1u.O);r.7("2c",r[0].1u.W);5(e(8).2r("a")&&e(8).1E().V>0){r=e(8).1E()}r.7("20",r.B());r.7("1N",r.H());r.7("4p",r.z("1s-O"));r.7("4s",r.z("1s-12"));r.7("4A",r.z("1s-W"));r.7("4z",r.z("1s-R"));5(r.z("1K-O-B").11("17")==-1){r.7("40",r[0].1u.5V)}D{r.7("40",r.z("1K-O-B"))}5(r.z("1K-12-B").11("17")==-1){r.7("3Z",r[0].1u.5X)}D{r.7("3Z",r.z("1K-12-B"))}5(r.z("1K-W-B").11("17")==-1){r.7("3t",r[0].1u.5Y)}D{r.7("3t",r.z("1K-W-B"))}5(r.z("1K-R-B").11("17")==-1){r.7("3o",r[0].1u.61)}D{r.7("3o",r.z("1K-R-B"))}r.7("6u",r.z("6m-6t"));r.7("6k",r.z("6h-H"))});5(3V.5e.59){2v(j t=0;t<e(n).k(".4-1a").V;t++){5(e(n).k(".4-1a").1Y(t).7("70")==3V.5e.59.1i("#")[1]){i.o.1j=t+1}}}e(n).k(\'*[M*="4-4h-"]\').1c(q(){j t=e(8).F("M").1i(" ");2v(j r=0;r<t.V;r++){5(t[r].11("4-4h-")!=-1){j i=A(t[r].1i("4-4h-")[1]);e(8).z({6R:"6Q"}).1p(q(t){t.1I();e(n).1w(i)})}}});i.g.1z=e(n).k(".4-1a").V;5(i.o.3m&&i.g.1z>2){i.o.1j=="3P";i.o.4W=L}D{i.o.3m=L}5(i.o.1j=="3P"){i.o.1j=2o.4a(2o.3P()*i.g.1z+1)}i.o.1j=i.o.1j<i.g.1z+1?i.o.1j:1;i.o.1j=i.o.1j<1?1:i.o.1j;i.g.2h=1;5(i.o.2B){i.g.2h=0}e(n).k(\'1n[J*="2W.3a"]\').1c(q(){5(e(8).1y(\'[M*="4-s"]\')){j t=e(8);e.5L("4r://6P.5b.4u/6B/5D/6S/"+e(8).F("J").1i("5d/")[1].1i("?")[0]+"?v=2&7c=5B&5F=?",q(e){t.7("3n",A(e["7d"]["6X$6Z"]["74$5G"]["71"])*3U)});j n=e("<U>").16("4-38").Q(e(8).1y());e("<1q>").Q(n).16("4-1W").F("J","4r://1q.5b.4u/73/"+e(8).F("J").1i("5d/")[1].1i("?")[0]+"/"+i.o.6n);e("<U>").Q(n).16("4-5K");e(8).1y().z({B:e(8).B(),H:e(8).H()}).1p(q(){i.g.1U=C;5(i.g.23){5(i.o.27!=L){i.g.23=L}i.g.1O=C}D{i.g.1O=i.g.1B}5(i.o.27!=L){i.I()}i.g.3g=C;e(8).k("1n").F("J",e(8).k("1n").7("31"));e(8).k(".4-38").1L(i.g.v.d).1Z(i.g.v.4H,q(){5(i.o.27=="1k"&&i.g.1O==C){j e=2w(q(){i.1h()},t.7("3n")-i.g.v.d);t.7("3L",e)}i.g.1U=L})});j r="&";5(e(8).F("J").11("?")==-1){r="?"}e(8).7("31",e(8).F("J")+r+"5H=1");e(8).7("20",e(8).F("B"));e(8).7("1N",e(8).F("H"));e(8).F("J","")}});e(n).k(\'1n[J*="2U.2F"]\').1c(q(){5(e(8).1y(\'[M*="4-s"]\')){j t=e(8);j n=e("<U>").16("4-38").Q(e(8).1y());e.5L("4r://2F.4u/5D/6Y/5C/"+e(8).F("J").1i("5C/")[1].1i("?")[0]+".5B?5F=?",q(r){e("<1q>").Q(n).16("4-1W").F("J",r[0]["7e"]);t.7("3n",A(r[0]["5G"])*3U);e("<U>").Q(n).16("4-5K")});e(8).1y().z({B:e(8).B(),H:e(8).H()}).1p(q(){i.g.1U=C;5(i.g.23){5(i.o.27!=L){i.g.23=L}i.g.1O=C}D{i.g.1O=i.g.1B}5(i.o.27!=L){i.I()}i.g.3g=C;e(8).k("1n").F("J",e(8).k("1n").7("31"));e(8).k(".4-38").1L(i.g.v.d).1Z(i.g.v.4H,q(){5(i.o.27=="1k"&&i.g.1O==C){j e=2w(q(){i.1h()},t.7("3n")-i.g.v.d);t.7("3L",e)}i.g.1U=L})});j r="&";5(e(8).F("J").11("?")==-1){r="?"}e(8).7("31",e(8).F("J")+r+"5H=1");e(8).7("20",e(8).F("B"));e(8).7("1N",e(8).F("H"));e(8).F("J","")}});5(i.o.2B){i.o.1j=i.o.1j-1==0?i.g.1z:i.o.1j-1}i.g.1l=i.o.1j;i.g.10=e(n).k(".4-1a:1Y("+(i.g.1l-1)+")");e(n).k(".4-1a").78(\'<U M="4-2e"></U>\');5(e(n).z("2l")=="7a"){e(n).z("2l","5q")}e(n).k(".4-2e").z({6T:i.o.58});5(i.o.54){e(n).k(".4-2e").z({6F:"2X("+i.o.54+")"})}5(i.o.4V){e(\'<a M="4-N-1g" 1o="#" />\').1p(q(t){t.1I();e(n).1w("1g")}).Q(e(n));e(\'<a M="4-N-1e" 1o="#" />\').1p(q(t){t.1I();e(n).1w("1e")}).Q(e(n));5(i.o.6a){e(n).k(".4-N-1g, .4-N-1e").z({1m:"1F"});e(n).13(q(){e(n).k(".4-N-1g, .4-N-1e").I(C,C).1X(1M)},q(){e(n).k(".4-N-1g, .4-N-1e").I(C,C).1Z(1M)})}}5(i.o.3X||i.o.3K){j r=e(\'<U M="4-R-N-2f" />\').Q(e(n));5(i.o.1G=="2p"){r.16("4-5u-3N")}5(i.o.3K&&i.o.1G!="2p"){e(\'<32 M="4-R-2q" />\').Q(e(n).k(".4-R-N-2f"));5(i.o.1G=="13"){j s=e(\'<U M="4-P-13"><U M="4-P-13-2e"><U M="4-P-13-2m"></U><U M="4-P-13-1q"><1q></U><32></32></U></U>\').Q(e(n).k(".4-R-2q"))}2v(x=1;x<i.g.1z+1;x++){j o=e(\'<a 1o="#" />\').Q(e(n).k(".4-R-2q")).1p(q(t){t.1I();e(n).1w(e(8).2t()+1)});5(i.o.1G=="13"){e(n).k(".4-P-13, .4-P-13-1q").z({B:i.o.4K,H:i.o.34});j u=e(n).k(".4-P-13");j a=u.k("1q").z({H:i.o.34});j f=e(n).k(".4-P-13-2e").z({1H:"2H",1m:"2a"});o.13(q(){j t=e(n).k(".4-1a").1Y(e(8).2t());5(t.k(".4-44").V){j r=t.k(".4-44").F("J")}D 5(t.k(".4-1W").V){j r=t.k(".4-1W").F("J")}D 5(t.k(".4-2m").V){j r=t.k(".4-2m").F("J")}D{j r=i.o.2g+i.o.1x+"/4w.4v"}e(n).k(".4-P-13-1q").z({O:A(u.z("1s-O")),W:A(u.z("1s-W"))});a.1D(q(){5(e(8).B()==0){a.z({2l:"5q",2D:"0 1k",O:"1k"})}D{a.z({2l:"6w",1Q:-e(8).B()/2,O:"50%"})}}).F("J",r);u.z({1m:"2a"}).I().1P({O:e(8).2l().O+(e(8).B()-u.6b())/2},4l,"3Y");f.z({1m:"1F",1H:"3c"}).I().1X(4l)},q(){f.I().1Z(4l,q(){u.z({1H:"2H",1m:"2a"})})})}}5(i.o.1G=="13"){s.Q(e(n).k(".4-R-2q"))}e(n).k(".4-R-2q a:1Y("+(i.o.1j-1)+")").16("4-N-1b")}5(i.o.3X){j l=e(\'<a M="4-N-1h" 1o="#" />\').1p(q(t){t.1I();e(n).1w("1h")}).5x(e(n).k(".4-R-N-2f"));j c=e(\'<a M="4-N-I" 1o="#" />\').1p(q(t){t.1I();e(n).1w("I")}).Q(e(n).k(".4-R-N-2f"))}D 5(i.o.1G!="2p"){e(\'<32 M="4-N-5w 4-N-6G" />\').5x(e(n).k(".4-R-N-2f"));e(\'<32 M="4-N-5w 4-N-6L" />\').Q(e(n).k(".4-R-N-2f"))}5(i.o.4X&&i.o.1G!="2p"){r.z({1m:"1F"});e(n).13(q(){r.I(C,C).1X(1M)},q(){r.I(C,C).1Z(1M)})}}5(i.o.1G=="2p"){j h=e(\'<U M="4-P-2f"></U>\').Q(e(n));j s=e(\'<U M="4-P"><U M="4-P-2e"><U M="4-P-18-1J"><U M="4-P-18"></U></U></U></U>\').Q(h);i.g.3N=e(n).k(".4-P-18-1J").13(q(){e(8).16("4-P-18-13")},q(){e(8).2n("4-P-18-13");i.56()}).6O(q(t){j n=A(t.7v-e(8).68().O)/e(8).B()*(e(8).B()-e(8).k(".4-P-18").B());e(8).k(".4-P-18").I().z({1Q:n})});e(n).k(".4-1a").1c(q(){j t=e(8).2t()+1;5(e(8).k(".4-44").V){j r=e(8).k(".4-44").F("J")}D 5(e(8).k(".4-1W").V){j r=e(8).k(".4-1W").F("J")}D 5(e(8).k(".4-2m").V){j r=e(8).k(".4-2m").F("J")}5(r){j s=e(\'<a 1o="#" M="4-24-\'+t+\'"><1q J="\'+r+\'"></a>\')}D{j s=e(\'<a 1o="#" M="4-4w 4-24-\'+t+\'"><1q J="\'+i.o.2g+i.o.1x+\'/4w.4v"></a>\')}s.13(q(){e(8).1E().I().3u(1M,i.o.4J/1f)},q(){5(!e(8).1E().3d("4-24-1b")){e(8).1E().I().3u(1M,i.o.4I/1f)}}).Q(e(n).k(".4-P-18")).1p(q(r){r.1I();e(n).1w(t)})});5(l&&c){j p=e(\'<U M="4-R-N-2f 4-87-3N"></U>\').Q(e(n));l.5y().1p(q(t){t.1I();e(n).1w("1h")}).Q(p);c.5y().1p(q(t){t.1I();e(n).1w("I")}).Q(p)}5(i.o.4X){h.z({1H:"2H"});5(p){j d=p.z("1m")=="2a"?p:e(n).k(".4-5u-3N");d.z({1m:"1F"})}e(n).13(q(){h.z({1H:"3c",1m:"1F"}).I(C,L).1X(1M);5(d){d.I(C,C).1X(1M)}},q(){h.I(C,C).1Z(1M,q(){e(8).z({1H:"2H",1m:"2a"})});5(d){d.I(C,C).1Z(1M)}})}}j v=e(\'<U M="4-2J"></U>\').Q(e(n));v.7("1N",v.H());5t=53;2w(q(){5(e(n).k(".4-2J").z("1m")=="2a"){e("<1q />").F("J",i.o.2g+i.o.1x+"/2J.4v").Q(e(n).k(".4-2J"))}},5t);5(i.o.5v&&e(n).k(".4-1a").V>1){e("2M").3Q("8a",q(e){5(!i.g.1U){5(e.5p==37){i.o.3G(i.g);i.1g("3M")}D 5(e.5p==39){i.o.3C(i.g);i.1e("3M")}}})}5("8d"5o 22&&e(n).k(".4-1a").V>1&&i.o.6o){e(n).3Q("8c",q(e){j t=e.2P?e.2P:e.5r.2P;5(t.V==1){i.g.3S=i.g.3i=t[0].5s}});e(n).3Q("86",q(e){j t=e.2P?e.2P:e.5r.2P;5(t.V==1){i.g.3i=t[0].5s}5(2o.5A(i.g.3S-i.g.3i)>45){e.1I()}});e(n).3Q("7Z",q(t){5(2o.5A(i.g.3S-i.g.3i)>45){5(i.g.3S-i.g.3i>0){i.o.3C(i.g);e(n).1w("1e")}D{i.o.3G(i.g);e(n).1w("1g")}}})}5(i.o.5a==C&&e(n).k(".4-1a").V>1){e(n).k(".4-2e").13(q(){i.o.65(i.g);5(i.g.1B){i.g.23=C;i.I()}},q(){5(i.g.23==C){i.1h();i.g.23=L}})}i.4b();5(i.o.G){i.g.G=e("<1q>").16("4-80").Q(e(n)).F("1u",i.o.5m).z({1H:"2H",1m:"81"}).1D(q(){j t=0;5(!i.g.G){t=3U}2w(q(){i.g.G.7("20",i.g.G.B());i.g.G.7("1N",i.g.G.H());5(i.g.G.z("O")!="1k"){i.g.G.7("26",i.g.G[0].1u.O)}5(i.g.G.z("12")!="1k"){i.g.G.7("2T",i.g.G[0].1u.12)}5(i.g.G.z("W")!="1k"){i.g.G.7("2c",i.g.G[0].1u.W)}5(i.g.G.z("R")!="1k"){i.g.G.7("2Q",i.g.G[0].1u.R)}5(i.o.51!=L){e("<a>").Q(e(n)).F("1o",i.o.51).F("8g",i.o.6p).z({8f:"1F",8j:"1F"}).5J(i.g.G)}i.g.G.z({1m:"1F",1H:"3c"});i.4o()},t)}).F("J",i.o.G)}e(22).8t(q(){i.2Y(i.g.10,q(){29});5(i.g.G){i.4o()}});i.g.6e=C;5(i.o.2B==C){5(i.o.42){i.g.1B=C;e(n).k(".4-N-1h").16("4-N-1h-1b")}D{e(n).k(".4-N-I").16("4-N-I-1b")}i.1e()}D{i.30(i.g.10,q(){i.g.10.1X(3U,q(){e(8).16("4-1b");5(i.o.3H){e(8).1L(e(8).7("33")+25).8x(q(){e(8).k(".4-1W").1p();e(8).5P()})}i.g.10.k(\' > *[M*="4-s"]\').1c(q(){5(e(8).7("41")>0){i.3q(e(8))}})});i.52(i.g.1l);5(i.o.42){i.1h()}D{e(n).k(".4-N-I").16("4-N-I-1b")}})}i.o.5z(e(n))};i.1h=q(){5(i.g.1B){5(i.g.1r=="1g"&&i.o.4W){i.1g()}D{i.1e()}}D{i.g.1B=C;i.4Q()}e(n).k(".4-N-1h").16("4-N-1h-1b");e(n).k(".4-N-I").2n("4-N-I-1b")};i.4Q=q(){j t=e(n).k(".4-1b").7("3W")?A(e(n).k(".4-1b").7("3W")):i.o.4m;5(!i.o.2B&&!e(n).k(".4-1b").7("3W")){j r=e(n).k(".4-1a:1Y("+(i.o.1j-1)+")").7("3W");t=r?r:i.o.4m}2V(i.g.2Z);i.g.2Z=22.2w(q(){i.1h()},t)};i.I=q(){5(!i.g.23&&!i.g.1O){e(n).k(".4-N-I").16("4-N-I-1b");e(n).k(".4-N-1h").2n("4-N-1h-1b")}2V(i.g.2Z);i.g.1B=L};i.5c=q(t){5(e.2i(t.3e())=="8q"||e.2i(t.3e())=="8i"){29 t.3e()}D{29 t.1v("8l","8o").1v("8n","8m").1v("8y","8h").1v("8u","8r").1v("82","7V").1v("7W","7u").1v("7t","7w").1v("7x","7A").1v("7z","7y").1v("7s","7r").1v("7l","7k").1v("7j","7m").1v("7n","7q")}};i.1g=q(e){5(i.g.1l<2){i.g.2h+=1}5(i.g.2h>i.o.2b&&i.o.2b>0&&!e){i.g.2h=0;i.I();5(i.o.43==L){i.o.2b=0}}D{j t=i.g.1l<2?i.g.1z:i.g.1l-1;i.g.1r="1g";i.2G(t,i.g.1r)}};i.1e=q(e){5(!i.o.3m){5(!(i.g.1l<i.g.1z)){i.g.2h+=1}5(i.g.2h>i.o.2b&&i.o.2b>0&&!e){i.g.2h=0;i.I();5(i.o.43==L){i.o.2b=0}}D{j t=i.g.1l<i.g.1z?i.g.1l+1:1;i.g.1r="1e";i.2G(t,i.g.1r)}}D 5(!e){j t=i.g.1l;j n=q(){t=2o.4a(2o.3P()*i.g.1z)+1;5(t==i.g.1l){n()}D{i.g.1r="1e";i.2G(t,i.g.1r)}};n()}D 5(e){j t=i.g.1l<i.g.1z?i.g.1l+1:1;i.g.1r="1e";i.2G(t,i.g.1r)}};i.2G=q(t,r){5(i.g.3g==C){i.g.3g=L;i.g.1B=i.g.1O;i.g.10.k(\'1n[J*="2W.3a"], 1n[J*="2U.2F"]\').1c(q(){e(8).1y().k(".4-38").1X(i.g.v.4F,q(){e(8).1y().k("1n").F("J","")})})}e(n).k(\'1n[J*="2W.3a"], 1n[J*="2U.2F"]\').1c(q(){2V(e(8).7("3L"))});2V(i.g.2Z);i.g.2S=t;i.g.1d=e(n).k(".4-1a:1Y("+(i.g.2S-1)+")");5(!r){5(i.g.1l<i.g.2S){i.g.1r="1e"}D{i.g.1r="1g"}}j s=0;5(e(n).k(\'1n[J*="2W.3a"], 1n[J*="2U.2F"]\').V>0){s=i.g.v.4F}2w(q(){i.30(i.g.1d,q(){i.1P()})},s)};i.30=q(t,n){5(i.o.30){j r=[];j s=0;5(t.z("2j-2N")!="1F"&&t.z("2j-2N").11("2X")!=-1){j o=t.z("2j-2N");o=o.4q(/2X\\((.*)\\)/)[1].1v(/"/5I,"");r.4n(o)}t.k("1q").1c(q(){r.4n(e(8).F("J"))});t.k("*").1c(q(){5(e(8).z("2j-2N")!="1F"&&e(8).z("2j-2N").11("2X")!=-1){j t=e(8).z("2j-2N");t=t.4q(/2X\\((.*)\\)/)[1].1v(/"/5I,"");r.4n(t)}});5(r.V==0){i.2Y(t,n)}D{2v(x=0;x<r.V;x++){e("<1q>").1D(q(){5(++s==r.V){i.2Y(t,n)}}).F("J",r[x])}}}D{i.2Y(t,n)}};i.2Y=q(t,r,s){5(!s){t.z({1H:"2H",1m:"2a"})}i.4b();5(i.o.1G=="2p"){i.62()}2v(j o=0;o<t.1E().V;o++){j u=t.1E(":1Y("+o+")");j a=u.7("26")?u.7("26"):"0";j f=u.7("2c")?u.7("2c"):"0";5(u.2r("a")&&u.1E().V>0){u=u.1E()}j l=u.7("20")?A(u.7("20"))*i.g.K:"1k";j c=u.7("1N")?A(u.7("1N"))*i.g.K:"1k";j h=u.7("4p")?A(u.7("4p"))*i.g.K:0;j p=u.7("4s")?A(u.7("4s"))*i.g.K:0;j d=u.7("4A")?A(u.7("4A"))*i.g.K:0;j v=u.7("4z")?A(u.7("4z"))*i.g.K:0;j m=u.7("40")?A(u.7("40"))*i.g.K:0;j g=u.7("3Z")?A(u.7("3Z"))*i.g.K:0;j y=u.7("3t")?A(u.7("3t"))*i.g.K:0;j b=u.7("3o")?A(u.7("3o"))*i.g.K:0;j w=u.7("6u");j E=u.7("6k");5(i.g.2d||i.o.2u>0){5(u.2r("1q")){u.z({B:"1k",H:"1k"});l=u.B();c=u.H();u.z({B:u.B()*i.g.K,H:u.H()*i.g.K})}5(!u.2r("1q")){u.z({B:l,H:c,"6m-6t":A(w)*i.g.K+"17","6h-H":A(E)*i.g.K+"17"})}5(u.2r("U")&&u.k("1n").7("31")){j S=u.k("1n");S.F("B",A(S.7("20"))*i.g.K).F("H",A(S.7("1N"))*i.g.K);u.z({B:A(S.7("20"))*i.g.K,H:A(S.7("1N"))*i.g.K})}u.z({1s:d+"17 "+p+"17 "+v+"17 "+h+"17 ",5V:m+"17",5X:g+"17",5Y:y+"17",61:b+"17"})}5(!u.3d("4-2m")){j x=u;5(u.1y().2r("a")){u=u.1y()}j T=i.o.4M>0?(i.g.14()-i.o.4M)/2:0;T=T<0?0:T;5(a.11("%")!=-1){u.z({O:i.g.14()/1f*A(a)-x.B()/2-h-m})}D 5(T>0||i.g.2d||i.o.2u>0){u.z({O:T+A(a)*i.g.K})}5(f.11("%")!=-1){u.z({W:i.g.19()/1f*A(f)-x.H()/2-d-y})}D 5(i.g.2d||i.o.2u>0){u.z({W:A(f)*i.g.K})}}D{u.z({B:"1k",H:"1k"});l=u.B();c=u.H();u.z({B:l*i.g.K,H:c*i.g.K,1Q:-(l*i.g.K/2)+"17",28:-(c*i.g.K/2)+"17"})}}5(!s){t.z({1m:"1F",1H:"3c"})}e(n).k(".4-2J").z({H:e(n).k(".4-2J").7("1N")*i.g.K});r();e(8).5P()};i.4o=q(){i.g.G.z({B:i.g.G.7("20")*i.g.K,H:i.g.G.7("1N")*i.g.K}).1X(1M);j t=3v=3w=3x="1k";5(i.g.G.7("26")&&i.g.G.7("26").11("%")!=-1){t=i.g.14()/1f*A(i.g.G.7("26"))-i.g.G.B()/2+A(e(n).z("1s-O"))}D{t=A(i.g.G.7("26"))*i.g.K}5(i.g.G.7("2T")&&i.g.G.7("2T").11("%")!=-1){3v=i.g.14()/1f*A(i.g.G.7("2T"))-i.g.G.B()/2+A(e(n).z("1s-12"))}D{3v=A(i.g.G.7("2T"))*i.g.K}5(i.g.G.7("2c")&&i.g.G.7("2c").11("%")!=-1){3w=i.g.19()/1f*A(i.g.G.7("2c"))-i.g.G.H()/2+A(e(n).z("1s-W"))}D{3w=A(i.g.G.7("2c"))*i.g.K}5(i.g.G.7("2Q")&&i.g.G.7("2Q").11("%")!=-1){3x=i.g.19()/1f*A(i.g.G.7("2Q"))-i.g.G.H()/2+A(e(n).z("1s-R"))}D{3x=A(i.g.G.7("2Q"))*i.g.K}i.g.G.z({O:t,12:3v,W:3w,R:3x})};i.62=q(){e(n).k(".4-P-18 a").z({B:A(i.o.4K*i.g.K),H:A(i.o.34*i.g.K)});e(n).k(".4-P-18 a:2C").z({2D:0});e(n).k(".4-P-18").z({H:A(i.o.34*i.g.K)});j t=e(n).k(".4-P");j r=i.o.3D.11("%")==-1?A(i.o.3D):A(A(i.g.1t)/1f*A(i.o.3D));t.z({B:r*2o.4a(i.g.K*1f)/1f});5(t.B()>e(n).k(".4-P-18").B()){t.z({B:e(n).k(".4-P-18").B()})}};i.52=q(t){j r=t?t:i.g.2S;e(n).k(".4-P-18 a:63(.4-24-"+r+")").1E().1c(q(){e(8).2n("4-24-1b").I().3u(4Y,i.o.4I/1f)});e(n).k(".4-P-18 a.4-24-"+r).1E().16("4-24-1b").I().3u(4Y,i.o.4J/1f)};i.56=q(){5(!e(n).k(".4-P-18-1J").3d("4-P-18-13")){j t=e(n).k(".4-24-1b").V?e(n).k(".4-24-1b").1y():L;5(t){j r=t.2l().O+t.B()/2;j i=e(n).k(".4-P-18-1J").B()/2-r;i=i>0?0:i;i=i<e(n).k(".4-P-18-1J").B()-e(n).k(".4-P-18").B()?e(n).k(".4-P-18-1J").B()-e(n).k(".4-P-18").B():i;e(n).k(".4-P-18").1P({1Q:i},4U,"3Y")}}};i.4b=q(){5(i.g.6e){e(n).z({1H:"3c"})}5(i.o.2u>0){5(e(22).B()<i.o.2u){i.g.2d=C;i.g.1t=i.o.2u+"17"}D{i.g.2d=L;i.g.1t=i.g.4d;i.g.K=1}}5(i.g.2d){j t=e(n).1y();e(n).z({B:t.B()-A(t.z("1s-O"))-A(t.z("1s-12"))-A(e(n).z("1s-O"))-A(e(n).z("1s-12"))});i.g.K=e(n).B()/A(i.g.1t);e(n).z({H:i.g.K*A(i.g.1T)})}D{i.g.K=1;e(n).z({B:i.g.1t,H:i.g.1T})}5(e(n).3f(".4-3b-2R-1J").V){e(n).3f(".4-3b-2R-69").z({H:e(n).67(C)});e(n).3f(".4-3b-2R-1J").z({H:e(n).67(C)});e(n).3f(".4-3b-2R-69").z({B:e(22).B(),O:-e(n).3f(".4-3b-2R-1J").68().O});5(i.g.1t.11("%")!=-1){j r=A(i.g.1t);j s=e("2M").B()/1f*r-(e(n).6b()-e(n).B());e(n).B(s)}}e(n).k(".4-2e").z({B:i.g.14(),H:i.g.19()});5(i.g.10&&i.g.1d){i.g.10.z({B:i.g.14(),H:i.g.19()});i.g.1d.z({B:i.g.14(),H:i.g.19()})}D{e(n).k(".4-1a").z({B:i.g.14(),H:i.g.19()})}};i.1P=q(){j t=i.g.10;i.o.6g(i.g);i.g.1U=C;5(i.o.1G=="2p"){i.52();i.56()}i.g.1d.16("4-5R");j r=4R=3z=4G=3y=4C=3B=4D=3E=7I=3A=7J="1k";j s=4E=i.g.14();j o=4S=i.g.19();j u=i.g.1r=="1g"?i.g.10:i.g.1d;j a=u.7("1R")?u.7("1R"):i.o.4k;j f=i.g.4L[i.g.1r][a];5(f=="O"||f=="12"){s=3z=4E=3B=0;3A=0}5(f=="W"||f=="R"){o=r=4S=3y=0;3E=0}2s(f){Y"O":4R=3y=0;3E=-i.g.14();X;Y"12":r=4C=0;3E=i.g.14();X;Y"W":4G=3B=0;3A=-i.g.19();X;Y"R":3z=4D=0;3A=i.g.19();X}i.g.10.z({O:r,12:4R,W:3z,R:4G});i.g.1d.z({B:4E,H:4S,O:3y,12:4C,W:3B,R:4D});5(i.o.2B&&i.g.1z==1){j l=0}D{j l=i.g.10.7("3s")?A(i.g.10.7("3s")):i.o.47;j c=i.g.10.7("2K")?A(i.g.10.7("2K")):i.o.3I;j h=i.g.10.7("2O")?i.g.10.7("2O"):i.o.3R;i.g.10.1L(l+c/15).1P({B:s,H:o},c,h,q(){t.k(\' > *[M*="4-s"]\').I(C,C);i.g.10=i.g.1d;i.g.1l=i.g.2S;e(n).k(".4-1a").2n("4-1b");e(n).k(".4-1a:1Y("+(i.g.1l-1)+")").16("4-1b").2n("4-5R");e(n).k(".4-R-2q a").2n("4-N-1b");e(n).k(".4-R-2q a:1Y("+(i.g.1l-1)+")").16("4-N-1b");i.g.1U=L;i.o.6f(i.g);5(i.g.1B){i.4Q()}});i.g.10.k(\' > *[M*="4-s"]\').1c(q(){j t=e(8).7("1R")?e(8).7("1R"):f;j n,r;2s(t){Y"O":n=-i.g.14();r=0;X;Y"12":n=i.g.14();r=0;X;Y"W":r=-i.g.19();n=0;X;Y"R":r=i.g.19();n=0;X}j s=e(8).7("3p")?e(8).7("3p"):L;2s(s){Y"O":n=i.g.14();r=0;X;Y"12":n=-i.g.14();r=0;X;Y"W":r=i.g.19();n=0;X;Y"R":r=-i.g.19();n=0;X}j o=i.g.10.7("46")?A(i.g.10.7("46")):i.o.49;j u=A(e(8).F("M").1i("4-s")[1])*o;j a=e(8).7("3s")?A(e(8).7("3s")):i.o.47;j l=e(8).7("2K")?A(e(8).7("2K")):i.o.3I;j c=e(8).7("2O")?e(8).7("2O"):i.o.3R;5(s=="2L"||!s&&t=="2L"){e(8).1L(a).1Z(l,c)}D{e(8).I().1L(a).1P({1Q:-n*u,28:-r*u},l,c)}})}j p=i.g.1d.7("33")?A(i.g.1d.7("33")):i.o.48;j d=i.g.1d.7("3j")?A(i.g.1d.7("3j")):i.o.4j;j v=i.g.1d.7("3k")?i.g.1d.7("3k"):i.o.4e;i.g.1d.1L(l+p).1P({B:i.g.14(),H:i.g.19()},d,v);i.g.1d.k(\' > *[M*="4-s"]\').1c(q(){j t=e(8).7("1R")?e(8).7("1R"):f;j n,r;2s(t){Y"O":n=-i.g.14();r=0;X;Y"12":n=i.g.14();r=0;X;Y"W":r=-i.g.19();n=0;X;Y"R":r=i.g.19();n=0;X;Y"2L":r=0;n=0;X}j s=i.g.1d.7("5Q")?A(i.g.1d.7("5Q")):i.o.6i;j o=A(e(8).F("M").1i("4-s")[1])*s;j u=e(8).7("33")?A(e(8).7("33")):i.o.48;j a=e(8).7("3j")?A(e(8).7("3j")):i.o.4j;j c=e(8).7("3k")?e(8).7("3k"):i.o.4e;5(t=="2L"){e(8).z({1m:"1F",1Q:0,28:0}).1L(l+u).1X(a,c,q(){5(i.o.3H==C){e(8).k(".4-1W").1p()}5(e(8).7("41")>0){i.3q(e(8))}})}D{e(8).z({1Q:n*o,28:r*o,1m:"2a"}).I().1L(l+u).1P({1Q:0,28:0},a,c,q(){5(i.o.3H==C){e(8).k(".4-1W").1p()}5(e(8).7("41")>0){i.3q(e(8))}})}})};i.3q=q(e){j t=i.g.10;5(i.g.1r!="1g"&&i.g.1d){t=i.g.1d}j n=t.7("1R")?t.7("1R"):i.o.4k;j r=i.g.4L[i.g.1r][n];j s=e.7("1R")?e.7("1R"):r;j o,u;2s(s){Y"O":o=-i.g.14();u=0;X;Y"12":o=i.g.14();u=0;X;Y"W":u=-i.g.19();o=0;X;Y"R":u=i.g.19();o=0;X}j a=e.7("3p")?e.7("3p"):L;2s(a){Y"O":o=i.g.14();u=0;X;Y"12":o=-i.g.14();u=0;X;Y"W":u=i.g.19();o=0;X;Y"R":u=-i.g.19();o=0;X}j f=i.g.10.7("46")?A(i.g.10.7("46")):i.o.49;j l=A(e.F("M").1i("4-s")[1])*f;j c=A(e.7("41"));j h=e.7("2K")?A(e.7("2K")):i.o.3I;j p=e.7("2O")?e.7("2O"):i.o.3R;5(a=="2L"||!a&&s=="2L"){e.1L(c).1Z(h,p)}D{e.1L(c).1P({1Q:-o*l,28:-u*l},h,p)}};i.2E=q(){i.d={21:e("<U>"),1S:q(t){e("<5k>"+t+"</5k>").Q(i.d.21)},55:q(){e("<2k>").Q(i.d.21)},1V:q(t){e("<2k><2A>"+t+"</2A></2k>").Q(i.d.21)},1A:q(t){e("<2A>"+t+"</2A>").Q(i.d.21.k("2k:2C"))},4T:q(t){e("<2k>").Q(i.d.21.k("2k:2C 2A:2C"))},5M:q(e){i.d.21.k("2k:2C 2A:2C").13(q(){e.z({1K:"7O 7P 7C",28:A(e.z("2D-W"))-2,1Q:A(e.z("2D-O"))-2})},q(){e.z({1K:"7B",28:A(e.z("2D-W"))+2,1Q:A(e.z("2D-O"))+2})})},4P:q(){5(!e("2M").k(".4-2E-4N").V){j t=e("<U>").16("4-2E-4N").z({2l:"8p",7i:"8s",W:"36",12:"36",B:"83",1s:"84",2j:"7X","1K-7Y":"36",H:e(22).H()-60,4Z:0,4B:53}).Q(e("2M")).1P({4B:0,4Z:.9},4U,"3Y").1p(q(t){5(t.6r&&t.6s){e(8).1P({4B:53,4Z:0},4U,"3Y",q(){e(8).4O()})}});j n=e("<U>").z({B:"1f%",H:"1f%",88:"1k"}).Q(t);j r=e("<U>").z({B:"1f%"}).Q(n).5J(i.d.21)}},6U:q(){e("2M").k(".4-2E-4N").4O()}};e(n).1p(q(e){5(e.6r&&e.6s){i.d.4P()}})};i.1D()};t.57={2z:"3.6",23:L,3g:L,1B:L,1U:L,1z:3l,1r:"1e",2Z:3l,14:3l,19:3l,4L:{1g:{O:"12",12:"O",W:"R",R:"W"},1e:{O:"O",12:"12",W:"W",R:"R"}},v:{d:5f,4H:4Y,4F:5f}};t.5E={42:C,1j:1,4W:C,5v:C,30:C,4V:C,3X:C,3K:C,1x:"85",2g:"/3T/8k/",5a:C,58:"7o",54:L,2B:C,G:L,5m:"O: -36; W: -36;",51:L,6p:"7T",6o:C,2b:0,43:C,3H:C,27:"1k",6n:"7M.7L",5U:C,3m:L,2u:0,4M:0,1G:"13",4K:1f,34:60,3D:"60%",4J:35,4I:1f,6a:C,4X:L,5z:q(e){},66:q(e){},64:q(e){},65:q(e){},6g:q(e){},6f:q(e){},3G:q(e){},3C:q(e){},4k:"12",4m:7E,6i:.45,49:.45,4j:5h,3I:5h,4e:"5n",3R:"5n",48:0,47:0}})(6d)',62,531,'||||ls|if||data|this|||||||||||var|find||||||function|||||||||css|parseInt|width|true|else||attr|yourLogo|height|stop|src|ratio|false|class|nav|left|thumbnail|appendTo|bottom|||div|length|top|break|case|strong|curLayer|indexOf|right|hover|sliderWidth||addClass|px|slide|sliderHeight|layer|active|each|nextLayer|next|100|prev|start|split|firstLayer|auto|curLayerIndex|display|iframe|href|click|img|prevNext|padding|sliderOriginalWidth|style|replace|layerSlider|skin|parent|layersNum|aL|autoSlideshow|param|load|children|none|thumbnailNavigation|visibility|preventDefault|container|border|delay|300|originalHeight|originalAutoSlideshow|animate|marginLeft|slidedirection|aT|sliderOriginalHeight|isAnimating|aU|videopreview|fadeIn|eq|fadeOut|originalWidth|history|window|paused|thumb||originalLeft|autoPauseSlideshow|marginTop|return|block|loops|originalTop|responsiveMode|inner|wrapper|skinsPath|nextLoop|trim|background|ul|position|bg|removeClass|Math|always|slidebuttons|is|switch|index|responsiveUnder|for|setTimeout|loaded|LayerSlider|version|li|animateFirstLayer|last|margin|debug|vimeo|change|hidden|init|shadow|durationout|fade|body|image|easingout|touches|originalBottom|fullwidth|nextLayerIndex|originalRight|player|clearTimeout|www|url|makeResponsive|slideTimer|imgPreload|videoSrc|span|delayin|tnHeight||10px||vpcontainer||youtu|wp|visible|hasClass|toLowerCase|closest|pausedByVideo|html|touchEndX|durationin|easingin|null|randomSlideshow|videoDuration|originalBorderBottom|slideoutdirection|sublayerShowUntil|link|delayout|originalBorderTop|fadeTo|oR|oT|oB|nextLayerLeft|curLayerTop|layerMarginTop|nextLayerTop|cbNext|tnContainerWidth|layerMarginLeft|WordPress|cbPrev|autoPlayVideos|durationOut|rel|navButtons|videoTimer|clicked|thumbnails|br|random|bind|easingOut|touchStartX|layerslider|1e3|document|slidedelay|navStartStop|easeInOutQuad|originalBorderRight|originalBorderLeft|showuntil|autoStart|forceLoopNum|tn||parallaxout|delayOut|delayIn|parallaxOut|floor|resizeSlider|content|sliderOriginalWidthRU|easingIn|fired|cssContainer|linkto|text|durationIn|slideDirection|250|slideDelay|push|resizeYourLogo|originalPaddingLeft|match|http|originalPaddingRight|wpVersion|com|png|nothumb|lswpVersion|script|originalPaddingBottom|originalPaddingTop|marginRight|nextLayerRight|nextLayerBottom|nextLayerWidth|fi|curLayerBottom|fo|tnInactiveOpacity|tnActiveOpacity|tnWidth|slideDirections|sublayerContainer|console|remove|show|timer|curLayerRight|nextLayerHeight|aUU|600|navPrevNext|twoWaySlideshow|hoverBottomNav|750|opacity||yourLogoLink|changeThumb|150|globalBGImage|aeU|scrollThumb|global|globalBGColor|hash|pauseOnHover|youtube|ieEasing|embed|location|500|id|1500|type|properties|h1|LAYER|yourLogoStyle|easeInOutQuint|in|which|relative|originalEvent|clientX|shadowTimer|above|keybNav|sides|prependTo|clone|cbInit|abs|json|video|api|options|callback|duration|autoplay|gi|append|playvideo|getJSON|aF|typeof|el|dequeue|parallaxin|animating|head|extend|responsive|borderLeftWidth|meta|borderRightWidth|borderTopWidth|initialized||borderBottomWidth|resizeThumb|not|cbStop|cbPause|cbStart|outerHeight|offset|helper|hoverPrevNext|outerWidth|createStyleSheet|jQuery|showSlider|cbAnimStop|cbAnimStart|line|parallaxIn|curSkin|originalLineHeight|or|font|youtubePreview|touchNav|yourLogoTarget|force|shiftKey|altKey|size|originalFontSize|already|absolute|and|found|mistyped|insertBefore|feeds|stylesheet|were|Content|backgroundImage|sideleft|layers|FUNCTION|of|disabled|sideright|Trying|2e3|mousemove|gdata|pointer|cursor|videos|backgroundColor|hide|to|easing|media|v2|group|deeplink|seconds|Number|vi|yt|tagName|prop|Fallback|wrapAll|Sublayer|static|SUBLAYER|alt|entry|thumbnail_large|mode|with|Neither|zIndex|back|Elastic|elastic|Back|bounce|transparent|Init|Bounce|Circ|circ|quint|Cubic|pageX|Quint|sine|Expo|expo|Sine|0px|red|new|4e3|number|undefined|object|layerMarginRight|layerMarginBottom|fn|jpg|maxresdefault|jquery|2px|solid|WP|JS|controls|_blank|information|Quart|cubic|black|radius|touchend|yourlogo|bock|quart|300px|20px|glass|touchmove|below|overflow|Possibilities|keydown|without|touchstart|ontouchstart|Loading|textDecoration|target|easeOut|linear|outline|skins|easeinout|easeIn|easein|easeInOut|fixed|swing|Quad|10000000000|resize|quad|code|Skin|queue|easeout'.split('|'),0,{}))
;
/*
 * jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
 *
 * Uses the built in easing capabilities added In jQuery 1.1
 * to offer multiple easing options
 *
 * TERMS OF USE - jQuery Easing
 * 
 * Open source under the BSD License. 
 * 
 * Copyright Â© 2008 George McGinley Smith
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of 
 * conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list 
 * of conditions and the following disclaimer in the documentation and/or other materials 
 * provided with the distribution.
 * 
 * Neither the name of the author nor the names of contributors may be used to endorse 
 * or promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE. 
 *
*/

// t: current time, b: begInnIng value, c: change In value, d: duration
jQuery.easing['jswing'] = jQuery.easing['swing'];

jQuery.extend( jQuery.easing,
{
	def: 'easeOutQuad',
	swing: function (x, t, b, c, d) {
		//alert(jQuery.easing.default);
		return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
	},
	easeInQuad: function (x, t, b, c, d) {
		return c*(t/=d)*t + b;
	},
	easeOutQuad: function (x, t, b, c, d) {
		return -c *(t/=d)*(t-2) + b;
	},
	easeInOutQuad: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t + b;
		return -c/2 * ((--t)*(t-2) - 1) + b;
	},
	easeInCubic: function (x, t, b, c, d) {
		return c*(t/=d)*t*t + b;
	},
	easeOutCubic: function (x, t, b, c, d) {
		return c*((t=t/d-1)*t*t + 1) + b;
	},
	easeInOutCubic: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t*t + b;
		return c/2*((t-=2)*t*t + 2) + b;
	},
	easeInQuart: function (x, t, b, c, d) {
		return c*(t/=d)*t*t*t + b;
	},
	easeOutQuart: function (x, t, b, c, d) {
		return -c * ((t=t/d-1)*t*t*t - 1) + b;
	},
	easeInOutQuart: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t*t*t + b;
		return -c/2 * ((t-=2)*t*t*t - 2) + b;
	},
	easeInQuint: function (x, t, b, c, d) {
		return c*(t/=d)*t*t*t*t + b;
	},
	easeOutQuint: function (x, t, b, c, d) {
		return c*((t=t/d-1)*t*t*t*t + 1) + b;
	},
	easeInOutQuint: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t*t*t*t + b;
		return c/2*((t-=2)*t*t*t*t + 2) + b;
	},
	easeInSine: function (x, t, b, c, d) {
		return -c * Math.cos(t/d * (Math.PI/2)) + c + b;
	},
	easeOutSine: function (x, t, b, c, d) {
		return c * Math.sin(t/d * (Math.PI/2)) + b;
	},
	easeInOutSine: function (x, t, b, c, d) {
		return -c/2 * (Math.cos(Math.PI*t/d) - 1) + b;
	},
	easeInExpo: function (x, t, b, c, d) {
		return (t==0) ? b : c * Math.pow(2, 10 * (t/d - 1)) + b;
	},
	easeOutExpo: function (x, t, b, c, d) {
		return (t==d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
	},
	easeInOutExpo: function (x, t, b, c, d) {
		if (t==0) return b;
		if (t==d) return b+c;
		if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
		return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
	},
	easeInCirc: function (x, t, b, c, d) {
		return -c * (Math.sqrt(1 - (t/=d)*t) - 1) + b;
	},
	easeOutCirc: function (x, t, b, c, d) {
		return c * Math.sqrt(1 - (t=t/d-1)*t) + b;
	},
	easeInOutCirc: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return -c/2 * (Math.sqrt(1 - t*t) - 1) + b;
		return c/2 * (Math.sqrt(1 - (t-=2)*t) + 1) + b;
	},
	easeInElastic: function (x, t, b, c, d) {
		var s=1.70158;var p=0;var a=c;
		if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
		if (a < Math.abs(c)) { a=c; var s=p/4; }
		else var s = p/(2*Math.PI) * Math.asin (c/a);
		return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
	},
	easeOutElastic: function (x, t, b, c, d) {
		var s=1.70158;var p=0;var a=c;
		if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
		if (a < Math.abs(c)) { a=c; var s=p/4; }
		else var s = p/(2*Math.PI) * Math.asin (c/a);
		return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
	},
	easeInOutElastic: function (x, t, b, c, d) {
		var s=1.70158;var p=0;var a=c;
		if (t==0) return b;  if ((t/=d/2)==2) return b+c;  if (!p) p=d*(.3*1.5);
		if (a < Math.abs(c)) { a=c; var s=p/4; }
		else var s = p/(2*Math.PI) * Math.asin (c/a);
		if (t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
		return a*Math.pow(2,-10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )*.5 + c + b;
	},
	easeInBack: function (x, t, b, c, d, s) {
		if (s == undefined) s = 1.70158;
		return c*(t/=d)*t*((s+1)*t - s) + b;
	},
	easeOutBack: function (x, t, b, c, d, s) {
		if (s == undefined) s = 1.70158;
		return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
	},
	easeInOutBack: function (x, t, b, c, d, s) {
		if (s == undefined) s = 1.70158; 
		if ((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
		return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
	},
	easeInBounce: function (x, t, b, c, d) {
		return c - jQuery.easing.easeOutBounce (x, d-t, 0, c, d) + b;
	},
	easeOutBounce: function (x, t, b, c, d) {
		if ((t/=d) < (1/2.75)) {
			return c*(7.5625*t*t) + b;
		} else if (t < (2/2.75)) {
			return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
		} else if (t < (2.5/2.75)) {
			return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
		} else {
			return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
		}
	},
	easeInOutBounce: function (x, t, b, c, d) {
		if (t < d/2) return jQuery.easing.easeInBounce (x, t*2, 0, c, d) * .5 + b;
		return jQuery.easing.easeOutBounce (x, t*2-d, 0, c, d) * .5 + c*.5 + b;
	}
});

/*
 *
 * TERMS OF USE - EASING EQUATIONS
 * 
 * Open source under the BSD License. 
 * 
 * Copyright Â© 2001 Robert Penner
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of 
 * conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list 
 * of conditions and the following disclaimer in the documentation and/or other materials 
 * provided with the distribution.
 * 
 * Neither the name of the author nor the names of contributors may be used to endorse 
 * or promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE. 
 *
 */;


(function( $ ) {
  

  $.fn.customCheckbox = function() {

    return this.each(function() {

      // Get the original element
      var el = this;

      // Hide the checkbox
      $(this).hide();

      // Create replacement element
      var rep = $('<a href="#"><span></span></a>').addClass('ls-checkbox').insertAfter(this);

      // Set default state
      if($(this).is(':checked')) {
        $(rep).addClass('on');
      } else {
        $(rep).addClass('off');
      }

      // Click event
      $(rep).click(function(e) {

        e.preventDefault();

        if( $(el).is(':checked') ) {
          $(el).prop('checked', false);
          $(rep).removeClass('on').addClass('off');
        } else {
          $(el).prop('checked', true);
          $(rep).removeClass('off').addClass('on');
        }
      });
    });
  };

})( jQuery );


(function ($) {
  
  
  $(document).ready(function(){
    
    var drupal_base_path =  Drupal.settings.basePath;
   

   
  
    var LayerSlider = {

      uploadInput : null,
      dragContainer : null,
      dragIndex : 0,
      newIndex : 0,
      timeout : 0,
      counter : 0,

      selectMainTab : function(el) {

        // Remove highlight from the other tabs
        jQuery('#ls-main-nav-bar a').removeClass('active');

        // Highlight selected tab
        jQuery(el).addClass('active');

        // Hide other pages
        jQuery('#ls-pages .ls-page').removeClass('active');

        // Show selected page
        jQuery('#ls-pages .ls-page').eq( jQuery(el).index() ).addClass('active')
      },

      addLayer : function() {

        // Clone the sample layer page
        var clone = jQuery('#ls-sample > div').clone();
        
       // clone.find($('input[name="background"]')).attr('id', $(this).attr('id')+index)

        // Append to place
        clone.appendTo('#ls-layers');

        // Close other layers
        jQuery('#ls-layer-tabs a').removeClass('active');

        // Get layer index
        var index = clone.index();

        jQuery('#ls-layers .ls-layer-box').eq( index ).find('input[name="background"]').attr('id', 'upload-background-img-'+index);
        
        // Add layer tab
        var tab = jQuery('<a href="#">Layer #'+(index+1)+'<span class="ls-icon-layer-remove">x</span></a>').insertBefore('#ls-add-layer');

        // Open new layer
        tab.click();

        // Add sortables
        LayerSlider.addSortables();

        // Generate preview
        LayerSlider.generatePreview(index);
      },

      removeLayer : function(el) {

        if(confirm('Are you sure you want to remove this layer?')) {

          // Get menu item
          var item = jQuery(el).parent();

          // Get layer
          var layer = jQuery(el).closest('#ls-layer-tabs').next().children().eq( item.index() );

          // Open next or prev layer
          if(layer.next().length > 0) {
            item.next().click();

          } else if(layer.prev().length > 0) {
            item.prev().click();
          }

          // Remove menu item
          item.remove();

          // Remove the layer
          layer.remove();

          // Reindex layers
          LayerSlider.reindexLayers();
        }
      },

      selectLayer : function(el) {

        // Close other layers
        jQuery('#ls-layer-tabs a').removeClass('active');
        jQuery('#ls-layers .ls-layer-box').removeClass('active');

        // Open new layer
        jQuery(el).addClass('active');
        jQuery('#ls-layers .ls-layer-box').eq( jQuery(el).index() ).addClass('active');

        // Open first sublayer
        jQuery('#ls-layers .ls-layer-box').eq( jQuery(el).index() ).find('.ls-sublayers td:first').click();

        // Update preview
        LayerSlider.generatePreview( jQuery(el).index() );

        // Stop preview
        LayerSlider.stop();
      },

      duplicateLayer : function(el) {

        // Clone fix
        LayerSlider.cloneFix();

        // Get layer index
        var index = jQuery(el).closest('.ls-layer-box').index();

        // Append new tab
        jQuery('<a href="#">Layer #0<span>x</span></a>').insertBefore('#ls-layer-tabs a:last');

        // Rename tab
        LayerSlider.reindexLayers();

        // Clone layer
        var clone = jQuery(el).closest('.ls-layer-box').clone();

        // Append new layer
        clone.appendTo('#ls-layers');

        // Remove active class if any
        clone.removeClass('active');

        // Add sortables
        LayerSlider.addSortables();
      },

      addSublayer : function(el) {

        // Get clone from sample
        var clone = jQuery('#ls-sample .ls-sublayers > tr').clone();

        // Appent to place
        clone.appendTo( jQuery(el).prev().find('.ls-sublayers') );

        // Get sublayer index
        var index = clone.index();

        // Rewrite sublayer number
        clone.find('.ls-sublayer-number').html( index + 1);
        clone.find('.ls-sublayer-title').val('Sublayer #' + (index + 1) );

        // Open it
        clone.click();
      },

      selectSubLayer : function(el) {

        if(jQuery(el).index() == jQuery(el).parent().children('.active:first').index() ) {
          return;
        }

        // Close other sublayers
        jQuery(el).parent().children().removeClass('active');

        // Open the new one
        jQuery(el).addClass('active');
      },

      selectSublayerPage : function(el) {

        // Close previous page
        jQuery(el).parent().children().removeClass('active');
        jQuery(el).parent().next().find('.ls-sublayer-page').removeClass('active');

        // Open the selected one
        jQuery(el).addClass('active');
        jQuery(el).parent().next().find('.ls-sublayer-page').eq( jQuery(el).index() ).addClass('active');
      },

      removeSublayer : function(el) {

        if(!confirm('Are you sure you want to remove this sublayer?')) {
          return;
        }

        // Get sublayer
        var sublayer = jQuery(el).closest('tr');

        // Get layer index
        var layer = jQuery(el).closest('.ls-layer-box');

        // Open the next or prev sublayer
        if(sublayer.next().length > 0) {
          sublayer.next().click();

        } else if(sublayer.prev().length > 0) {
          sublayer.prev().click();
        }

        // Remove menu item
        jQuery(el).remove();

        // Remove sublayer
        sublayer.remove();

        // Update preview
        LayerSlider.generatePreview( layer.index() );
      },

      highlightSublayer : function(el) {

        if(jQuery(el).prop('checked') == true) {

          // Deselect other checkboxes
          jQuery('.ls-highlight input').not(el).prop('checked', false);

          // Restore sublayers in the preview
          jQuery(el).closest('.ls-layer-box').find('.draggable').children().css({
            opacity : 0.5
          });

          // Get element index
          var index = jQuery(el).closest('tr').index();

          // Highlight selected one
          jQuery(el).closest('.ls-layer-box').find('.draggable').children().eq(index).css({
            zIndex : 1000, 
            opacity : 1
          });

        } else {

          // Restore sublayers in the preview
          jQuery(el).closest('.ls-layer-box').find('.draggable').children().each(function(index) {
            jQuery(this).css({
              zIndex : 10 + index
            });
            jQuery(this).css('opacity', 1);
          });
        }
      },

      duplicateSublayer : function(el) {

        // Clone fix
        LayerSlider.cloneFix();

        // Clone sublayer
        var clone = jQuery(el).closest('.ls-sublayer-wrapper').closest('tr').clone();

        // Remove active class
        clone.removeClass('active');

        // Append
        clone.appendTo( jQuery(el).closest('.ls-sublayers')  );

        // Rename sublayer
        clone.find('.ls-sublayer-title').val( clone.find('.ls-sublayer-title').val() + ' copy' );
        LayerSlider.reindexSublayers( jQuery(el).closest('.ls-layer-box') );

        // Update preview
        LayerSlider.generatePreview( jQuery(el).closest('.ls-layer-box').index() );
      },

      skipSublayer : function(el) {

        LayerSlider.generatePreview( jQuery(el).closest('.ls-layer-box').index()  );
      },

      selectMediaType : function(el) {

        // Remove highlight from the others
        jQuery(el).parent().children().removeClass('active');

        // Highlight the selected one
        jQuery(el).addClass('active');

        // Deselect old elements
        jQuery(el).closest('.ls-sublayer-basic').find('select option').attr('selected', false);

        // Change the select option
        var option = jQuery(el).closest('.ls-sublayer-basic').find('select option').eq( jQuery(el).index() ).attr('selected', true);

        // Show / hide image upload field
        if(option.val() == 'img') {
          jQuery(el).closest('.ls-sublayer-basic').find('.ls-image-uploader').show();
          jQuery(el).closest('.ls-sublayer-basic').find('.ls-html-code').hide();
        } else {
          jQuery(el).closest('.ls-sublayer-basic').find('.ls-image-uploader').hide();
          jQuery(el).closest('.ls-sublayer-basic').find('.ls-html-code').show();
        }
      },

      didSelectMediaType : function(el) {
        LayerSlider.selectMediaType(el);
        LayerSlider.generatePreview( jQuery(el).closest('.ls-layer-box').index() );
      },

      setCallbackBoxesWidth : function() {

        jQuery('.ls-callback-box').width( (jQuery('.wrap').width() - 26) / 3);
      },

      willGeneratePreview : function(index) {
        clearTimeout(LayerSlider.timeout);
        LayerSlider.timeout = setTimeout(function() {

          if(index == -1) {
            jQuery('#ls-layers .ls-layer-box').each(function( index ) {
              LayerSlider.generatePreview(index);
            });
          } else {
            LayerSlider.generatePreview(index);
          }
        }, 1000);
      },

      generatePreview : function(index) {

        // Get preview element
        var preview = jQuery('.ls-preview').eq( index + 1 );

        // Get the draggable element
        var draggable = preview.find('.draggable');

        // Get sizes
        var width = jQuery('.ls-settings input[name="width"]').val();
        var height = jQuery('.ls-settings input[name="height"]').val();
        var sub_container = jQuery('.ls-settings input[name="sublayercontainer"]').val();

        // Which width?
        if(sub_container != '' && sub_container != 0) {
          width = sub_container;
        }

        // Set sizes
        preview.add(draggable).css({
          width : width, 
          height : height
        });
        preview.parent().css({
          width : width
        });

        // Get backgrounds
        var bgColor = jQuery('.ls-settings input[name="backgroundcolor"]').val();
        var bgImage = jQuery('.ls-settings input[name="backgroundimage"]').val();

        // Set backgrounds
        if(bgColor != '') {
          preview.css({
            backgroundColor : bgColor
          });
        } else {
          preview.css({
            backgroundColor : 'transparent'
          });
        }

        if(bgImage != '') {
          preview.css({
            backgroundImage : 'url('+bgImage+')'
          });
        } else {
          preview.css({
            backgroundImage : 'none'
          });
        }

        // Get yourLogo
        var yourLogo = jQuery('.ls-settings input[name="yourlogo"]').val();
        var yourLogoStyle = jQuery('.ls-settings input[name="yourlogostyle"]').val();

        // Remove previous yourLogo
        preview.parent().find('.yourlogo').remove();

        // Set yourLogo
        if(yourLogo && yourLogo != '') {
          var logo = jQuery('<img src="'+yourLogo+'" class="yourlogo">').prependTo( jQuery(preview).parent() );
          logo.attr('style', yourLogoStyle);

          var oL = oR = oT = oB = 'auto';

          if( logo.css('left') != 'auto' ){
            var logoLeft = logo[0].style.left;
          }
          if( logo.css('right') != 'auto' ){
            var logoRight = logo[0].style.right;
          }
          if( logo.css('top') != 'auto' ){
            var logoTop = logo[0].style.top;
          }
          if( logo.css('bottom') != 'auto' ){
            var logoBottom = logo[0].style.bottom;
          }

          if( logoLeft && logoLeft.indexOf('%') != -1 ){
            oL = width / 100 * parseInt( logoLeft ) - logo.width() / 2;
          }else{
            oL = parseInt( logoLeft );
          }

          if( logoRight && logoRight.indexOf('%') != -1 ){
            oR = width / 100 * parseInt( logoRight ) - logo.width() / 2;
          }else{
            oR = parseInt( logoRight );
          }

          if( logoTop && logoTop.indexOf('%') != -1 ){
            oT = height / 100 * parseInt( logoTop ) - logo.height() / 2;
          }else{
            oT = parseInt( logoTop );
          }

          if( logoBottom && logoBottom.indexOf('%') != -1 ){
            oB = height / 100 * parseInt( logoBottom ) - logo.height() / 2;
          }else{
            oB = parseInt( logoBottom );
          }

          logo.css({
            left : oL,
            right : oR,
            top : oT,
            bottom : oB
          });
        }

        // Get layer background
        var background = jQuery('#ls-layers .ls-layer-box').eq(index).find('input[name="background"]').val();

        // Set layer background
        if(background != '') {
          draggable.css({
            backgroundImage : 'url('+background+')',
            backgroundPosition : 'center center'
          });
        } else {
          draggable.css({
            backgroundImage : 'none'
          });
        }

        // Empty draggable
        draggable.children().remove();

        // Iterate over the sublayers
        jQuery('#ls-layers .ls-layer-box').eq(index).find('.ls-sublayers > tr').each(function() {

          // Get sublayer type
          var type = jQuery(this).find('select[name="type"] option:selected').val()

          // Get image URL
          var url = jQuery(this).find('input[name="image"]').val();

          // Skip?
          var skip = jQuery(this).find('input[name="skip"]').prop('checked');

          // WordWrap
          var wordWrap = jQuery(this).find('input[name="wordwrap"]').prop('checked');


          // Append element
          if(skip) {
            jQuery('<div>').appendTo(draggable);
            return true;

          } else if(type == 'img') {
            if(url != '') {
              var item = jQuery('<img src="'+url+'">').appendTo(draggable);
            } else {
              var item =jQuery('<div>').appendTo(draggable);
            }
          } else {

            // Get HTML content
            var html = jQuery(this).find('textarea[name="html"]').val();

            // Append the element
            var item =jQuery('<'+type+'>').appendTo(draggable);

            // Set HTML
            if(html != '') {
              item.html(html);
            }
          }

          // Abs pos
          item.css('position', 'absolute');

          // Get style settings
          var top = jQuery(this).find('input[name="top"]').val();
          var left = jQuery(this).find('input[name="left"]').val();
          var custom = jQuery(this).find('textarea[name="style"]').val();

          // Set custom style settings
          item.attr('style', custom);

          // Word wrap
          if(wordWrap == false) {
            item.css('white-space', 'nowrap');
          }

          var pt = isNaN( parseInt( item.css('padding-top') ) ) ? 0 : parseInt( item.css('padding-top') );
          var pl = isNaN( parseInt( item.css('padding-left') ) ) ? 0 : parseInt( item.css('padding-left') );
          var bt = isNaN( parseInt( item.css('border-top-width') ) ) ? 0 : parseInt( item.css('border-top-width') );
          var bl = isNaN( parseInt( item.css('border-left-width') ) ) ? 0 : parseInt( item.css('border-left-width') );

          var setPositions = function(){

            // Position the element
            if(top.indexOf('%') != -1) {
              item.css({
                top : draggable.height() / 100 * parseInt( top ) - item.height() / 2 - pt - bt
              });
            } else {
              item.css({
                top : parseInt(top)
              });
            }

            if(left.indexOf('%') != -1) {
              item.css({
                left : draggable.width() / 100 * parseInt( left ) - item.width() / 2 - pl - bl
              });
            } else {
              item.css({
                left : parseInt(left)
              });
            }
          };

          if( item.is('img') ){

            item.load(function(){
              setPositions();
            }).attr('src',item.attr('src') );
          }else{
            setPositions();
          }

          // Z-index
          item.css({
            zIndex : 10 + item.index()
          });


          // Add draggable
          LayerSlider.addDraggable();
        });
      },

      openMediaLibrary : function() {

        // Bind upload button to show media uploader
        jQuery('.ls-upload').live('click', function() {
          uploadInput = this;
          
          
          // tb_show('Upload or select a new image to insert into LayerSlider', '/imce?app=myApp|url@layer-thumbnail-0&amp;TB_iframe=true&width=650&height=400');
         
         
         myItem = $(this);
          if(myItem.attr('name') == 'image'){
           
           $('.ls-sublayer-pages .ls-sublayer-page').each(function(index){
             
             tmp_ls = $(this);
             
             tmp_ls.find('.ls-upload').attr('id', 'ls-upload-img'+index);
             
            
            
           });
           
           
           window.open(drupal_base_path+'?q=imce&app=LayerSlider|url@'+myItem.attr('id'), '', 'width=760,height=560,resizable=1');
           
           
          }else{
            window.open(drupal_base_path+'?q=imce&app=LayerSlider|url@'+myItem.attr('id'), '', 'width=760,height=560,resizable=1');
          }
          
          
          return false;
        });
        
        
        
        
      },

      insertUpload : function() {

        // Bind an event to image url insert
        window.send_to_editor = function(html) {

          // Get the image URL
          var img = jQuery('img',html).attr('src');

          // Set image URL
          jQuery(uploadInput).val( img );

          // Remove thickbox window
          tb_remove();

          // Generate preview
          jQuery('#ls-layers .ls-layer-box').each(function( index ) {
            LayerSlider.generatePreview(index);
          });

          // Image sublayer
          if(jQuery(uploadInput).is('input[name="image"]')) {
            jQuery(uploadInput).prev().attr('src', img);
          }
        };
      },

      addSortables : function() {

        // Bind sortable function
        jQuery('.ls-sublayer-sortable').sortable({
          axis : 'y',

          helper: function(e, tr) {
            var $originals = tr.children();
            var $helper = tr.clone();
            $helper.children().each(function(index) {

              // Set helper cell sizes to match the original sizes
              jQuery(this).width($originals.eq(index).width());
            });
            return $helper;
          },
          sort : function(event, ui){
            LayerSlider.dragContainer = jQuery('.ui-sortable-helper').closest('.ls-layer-box');
          },
          stop : function(event, ui) {
            LayerSlider.generatePreview( LayerSlider.dragContainer.index() );
            LayerSlider.reindexSublayers( LayerSlider.dragContainer );
          },
          containment : 'parent',
          tolerance : 'pointer'
        });
      },

      addLayerSortables : function() {

        // Bind sortable function
        jQuery('#ls-layer-tabs').sortable({
          //axis : 'x',
          start : function() {
            LayerSlider.dragIndex = jQuery('.ui-sortable-placeholder').index() - 1;
          },
          change: function() {
            jQuery('.ui-sortable-helper').addClass('moving');
          },
          stop : function(event, ui) {

            // Get old index
            var oldIndex = LayerSlider.dragIndex;

            // Get new index
            var index = jQuery('.moving').index();

            if( index > -1 ){

              // Rearraange layer pages

              if(index == 0) {
                jQuery('#ls-layers .ls-layer-box').eq(oldIndex).prependTo('#ls-layers');
              }else{
                var layerObj = jQuery('#ls-layers .ls-layer-box').eq(oldIndex);
                jQuery('#ls-layers .ls-layer-box').eq(oldIndex).remove();

                layerObj.insertAfter('#ls-layers .ls-layer-box:eq('+(index-1)+')');
              }
            }

            jQuery('.moving').removeClass('moving');

            // Reindex layers
            LayerSlider.reindexLayers();
          },
          containment : 'parent',
          tolerance : 'pointer',
          items : 'a:not(.unsortable)'
        });
      },

      addDraggable : function() {
        jQuery('.draggable').children().draggable({
          drag : function() {

            LayerSlider.dragging();
          },
          stop : function() {

            LayerSlider.dragging();
          }
        });
      },

      dragging : function() {

        // Get positions
        var top = jQuery('.ui-draggable-dragging').position().top;
        var left = jQuery('.ui-draggable-dragging').position().left;

        // Get index
        var wrapper = jQuery('.ui-draggable-dragging').closest('.ls-layer-box');
        var index = jQuery('.ui-draggable-dragging').index();

        // Set positions
        wrapper.find('input[name="top"]').eq(index).val(top + 'px');
        wrapper.find('input[name="left"]').eq(index).val(left + 'px');
      },

      selectDragElement : function(el) {

        jQuery(el).closest('.ls-layer-box').find('.ls-sublayers > tr').eq( jQuery(el).index() ).click();
        jQuery(el).closest('.ls-layer-box').find('.ls-sublayers > tr').eq( jQuery(el).index() ).find('.ls-sublayer-nav a:eq(1)').click();
      },

      reindexSublayers : function(el) {

        jQuery(el).find('.ls-sublayers > tr').each(function(index) {

          // Reindex sublayer number
          jQuery(this).find('.ls-sublayer-number').html( index + 1 );

          // Reindex sublayer title if it is untoched
          if(
            jQuery(this).find('.ls-sublayer-title').val().indexOf('Sublayer') != -1 &&
            jQuery(this).find('.ls-sublayer-title').val().indexOf('copy') == -1
            ) {
            jQuery(this).find('.ls-sublayer-title').val('Sublayer #' + (index + 1) );
          }
        });
      },

      reindexLayers : function() {
        jQuery('#ls-layer-tabs a:not(.unsortable)').each(function(index) {
          jQuery(this).html('Layer #' + (index + 1) + '<span>x</span>');
        });
      },

      play : function( index ) {

        // Get layerslider contaier
        var layerslider = jQuery('#ls-layers .ls-layer-box').eq(index).find('.ls-real-time-preview');

        // Stop
        if(layerslider.children().length > 0) {
          jQuery('#ls-layers .ls-layer-box').eq(index).find('.ls-preview').show();
          layerslider.find('.ls-container').layerSlider('stop');
          layerslider.html('').hide();
          jQuery('#ls-layers .ls-layer-box').eq(index).find('.ls-preview-button').html('Enter Preview').removeClass('playing');
          return;
        }

        // Show the LayerSlider
        layerslider.show();
        layerslider = jQuery('<div class="layerslider">').appendTo(layerslider);

        // Hide the preview
        jQuery('#ls-layers .ls-layer-box').eq(index).find('.ls-preview').hide();

        // Change button status
        jQuery('#ls-layers .ls-layer-box').eq(index).find('.ls-preview-button').html('Exit Preview').addClass('playing');

        // Get global settings
        var width = jQuery('.ls-settings input[name="width"]').val();
        var height = jQuery('.ls-settings input[name="height"]').val();
        var backgroundColor = jQuery('.ls-settings input[name="backgroundcolor"]').val();
        var backgroundImage = jQuery('.ls-settings input[name="backgroundimage"]').val();

        // Apply global settings
        layerslider.css({
          width: width, 
          height : height
        });


        if(backgroundColor != '') {
          layerslider.css({
            backgroundColor : backgroundColor
          });
        }

        if(backgroundImage != '') {
          layerslider.css({
            backgroundImage : 'url('+backgroundImage+')'
          });
        }

        // Iterate over the layers
        jQuery('#ls-layers .ls-layer-box').each(function() {

          // Gather layer data
          var background = jQuery(this).find('input[name="background"]').val();
          var direction = jQuery(this).find('select[name="slidedirection"]:first option:selected').val();
          var delay = jQuery(this).find('input[name="slidedelay"]').val();

          var durationIn = jQuery(this).find('input[name="durationin"]').val();
          var easingIn = jQuery(this).find('select[name="easingin"] option:selected').val();
          var delayIn = jQuery(this).find('input[name="delayin"]').val();

          var durationOut = jQuery(this).find('input[name="durationout"]').val();
          var easingOut = jQuery(this).find('select[name="easingout"] option:selected').val();
          var delayOut = jQuery(this).find('input[name="delayout"]').val();

          // Build the layer
          var layer = jQuery('<div class="ls-layer">').appendTo(layerslider);
          layer.attr('rel', 'slidedirection:'+direction+';');
          layer.attr('rel', layer.attr('rel') + 'slidedelay:'+delay+';');
          layer.attr('rel', layer.attr('rel') + 'durationin:'+durationIn+';');
          layer.attr('rel', layer.attr('rel') + 'durationout:'+durationOut+';');
          layer.attr('rel', layer.attr('rel') + 'easingin:'+easingIn+';');
          layer.attr('rel', layer.attr('rel') + 'easingout:'+easingOut+';');
          layer.attr('rel', layer.attr('rel') + 'delayin:'+delayIn+';');
          layer.attr('rel', layer.attr('rel') + 'delayout:'+delayOut+';');

          // Background
          if(background != '') {
            jQuery('<img src="'+background+'" class="ls-bg">').appendTo(layer);
          }

          // Iterate over the sublayers
          jQuery(this).find('.ls-sublayers > tr').each(function(index) {

            // Gather sublayer data
            var type = jQuery(this).find('select[name="type"] option:selected').val();

            var image = jQuery(this).find('input[name="image"]').val();
            var html = jQuery(this).find('textarea[name="html"]').val();
            var style = jQuery(this).find('textarea[name="style"]').val();
            var top = jQuery(this).find('input[name="top"]').val();
            var left = jQuery(this).find('input[name="left"]').val();
            var level = jQuery(this).find('input[name="level"]').val();
            var skip = jQuery(this).find('input[name="skip"]').prop('checked');
            var url = jQuery(this).find('input[name="url"]').val();

            var directionIn = jQuery(this).find('select[name="slidedirection"] option:selected').val();
            var directionOut = jQuery(this).find('select[name="slideoutdirection"] option:selected').val();

            var durationIn = jQuery(this).find('input[name="durationin"]').val();
            var durationOut = jQuery(this).find('input[name="durationout"]').val();

            var easingIn = jQuery(this).find('select[name="easingin"] option:selected').val();
            var easingOut = jQuery(this).find('select[name="easingout"] option:selected').val();

            var delayIn = jQuery(this).find('input[name="delayin"]').val();
            var delayOut = jQuery(this).find('input[name="delayout"]').val();

            var showUntil = jQuery(this).find('input[name="showuntil"]').val();
            var wordWrap = jQuery(this).find('input[name="wordwrap"]').prop('checked');

            // Skip sublayer?
            if(skip) {
              return true;
            }

            // Build the sublayer
            if(type == 'img') {
              if(image != '') {
                var sublayer = jQuery('<img src="'+image+'">').appendTo(layer).addClass('ls-s'+level);
              } else {
                return true;
              }
            } else {
              var sublayer = jQuery('<'+type+'>').appendTo(layer).html(html).addClass('ls-s'+level);
            }

            // Custom style settings
            sublayer.attr('style', style);

            // WordWrap
            if(wordWrap == false) {
              sublayer.css('white-space', 'nowrap');
            }

            // Position the element
            if(top.indexOf('%') != -1) {
              sublayer.css({
                top : top, 
                marginTop : - sublayer.height() / 2 - parseInt( sublayer.css('padding-top') ) - parseInt( sublayer.css('border-top-width') )
              });
            } else {
              sublayer.css({
                top : parseInt(top)
              });
            }

            if(left.indexOf('%') != -1) {
              sublayer.css({
                left : left, 
                marginLeft : - sublayer.width() / 2 - parseInt( sublayer.css('padding-left') ) - parseInt( sublayer.css('border-left-width') )
              });
            } else {
              sublayer.css({
                left : parseInt(left)
              });
            }

            if(url != '' && url.match(/^\#[0-9]/)) {
              sublayer.addClass('ls-linkto-' + url.substr(1));
            }

            // Params
            sublayer.attr('rel', '');

            if(directionIn != 'auto') {
              sublayer.attr('rel', sublayer.attr('rel') + 'slidedirection:'+directionIn+';');
            }

            if(directionOut != 'auto') {
              sublayer.attr('rel', sublayer.attr('rel') + 'slideoutdirection:'+directionOut+';');
            }

            sublayer.attr('rel', sublayer.attr('rel') + 'durationin:'+durationIn+';');
            sublayer.attr('rel', sublayer.attr('rel') + 'durationout:'+durationOut+';');
            sublayer.attr('rel', sublayer.attr('rel') + 'easingin:'+easingIn+';');
            sublayer.attr('rel', sublayer.attr('rel') + 'easingout:'+easingOut+';');
            sublayer.attr('rel', sublayer.attr('rel') + 'delayin:'+delayIn+';');
            sublayer.attr('rel', sublayer.attr('rel') + 'delayout:'+delayOut+';');
            sublayer.attr('rel', sublayer.attr('rel') + 'showuntil:'+showUntil+';');
          });
        });

        // LayerSlider init params
        var skinPath = pluginPath + 'skins/';

        // Init layerslider
        jQuery(layerslider).layerSlider({
          width : width,
          height : height,
          skin : 'preview',
          skinsPath : skinPath,
          animateFirstLayer : true,
          firstLayer : (index + 1),
          autoStart : true,
          pauseOnHover : false
        });

      },


      stop : function() {

        // Get layerslider contaier
        var layersliders = jQuery('#ls-layers .ls-layer-box .ls-real-time-preview');

        // Stop the preview if any
        if(layersliders.children().length > 0) {

          // Show the editor
          jQuery('#ls-layers .ls-layer-box .ls-preview').show();

          // Stop LayerSlider
          layersliders.find('.ls-container').layerSlider('stop');

          // Empty and hide the Preview
          layersliders.html('').hide();

          // Rewrote the Preview button text
          jQuery('#ls-layers .ls-layer-box .ls-preview-button').text('Enter Preview').removeClass('playing');
        }
      },

      save : function(el) {

        // Temporary disable submit button
        jQuery('.ls-publish button').text('Saving ...').addClass('saving').attr('disabled', true);
        jQuery('.ls-saving-warning').text('Do not close this page when saving your layers!');

        // Iterate over the settings
        jQuery('.ls-settings input, .ls-settings select').each(function() {

          // Save original name attr to element's data
          jQuery(this).data('name', jQuery(this).attr('name') );

          // Rewrite the name attr
          jQuery(this).attr('name', 'layerslider-slides[properties]['+jQuery(this).attr('name')+']');
        });

        // Iterate over the layers
        jQuery('#ls-layers .ls-layer-box').each(function(layer) {

          // Iterate over layer settings
          jQuery(this).find('.ls-slide-options input, .ls-slide-options select').each(function() {

            // Save original name attr to element's data
            jQuery(this).data('name', jQuery(this).attr('name') );

            // Rewrite the name attr
            jQuery(this).attr('name', 'layerslider-slides[layers]['+layer+'][properties]['+jQuery(this).attr('name')+']');

          });

          // Iterate over the sublayers
          jQuery(this).find('.ls-sublayers > tr').each(function(sublayer) {

            // Iterate over the sublayer properties
            jQuery(this).find('input, select, textarea').each(function() {

              // Save original name attr to element's data
              jQuery(this).data('name', jQuery(this).attr('name') );

              // Rewrite the name attr
              jQuery(this).attr('name', 'layerslider-slides[layers]['+layer+'][sublayers]['+sublayer+']['+jQuery(this).attr('name')+']');
            });
          });
        });

        // Iterate over the callback functions
        jQuery('.ls-callback-page textarea').each(function() {

          // Save original name attr to element's data
          jQuery(this).data('name', jQuery(this).attr('name') );

          // Rewrite the name attr
          jQuery(this).attr('name', 'layerslider-slides[properties]['+jQuery(this).attr('name')+']');
        });

        // Reset layer counter
        LayerSlider.counter = 0;

        setTimeout(function() {

          // Iterate over the layers
          jQuery('#ls-layers .ls-layer-box').each(function(layer) {

            // Reindex layerkey
            jQuery(this).find('input[name="layerkey"]').val(layer);

            // Data to send
            $data = jQuery('#ls-layers .ls-layer-box').eq(layer).find('input, textarea, select');
            $data = $data.add( jQuery('#ls-slider-form > input')  );
            $data = $data.add( jQuery('.ls-settings').find('input, textarea, select') );
            $data = $data.add( jQuery('.ls-callback-page textarea') );

            // Post layer
            
             
            jQuery.ajax(jQuery(el).attr('action'), {
              type : 'POST',
              data : $data.serialize(),
              async : false,
              success : function(id) {

                LayerSlider.counter += 1;

                if(jQuery('#ls-layers .ls-layer-box').length == LayerSlider.counter) {

                  // Give feedback
                  jQuery('.ls-publish button').text('Saved').removeClass('saving').addClass('saved');
                  jQuery('.ls-saving-warning').text('');

                  // Re-enable the button
                  setTimeout(function() {
                    jQuery('.ls-publish button').text('Save changes').attr('disabled', false).removeClass('saved');
                  }, 2000);

                  // Rewrote original name attr

                  // Global settings
                  jQuery('.ls-settings input, .ls-settings select').each(function() {
                    jQuery(this).attr('name', jQuery(this).data('name'));
                  });

                  // Layers
                  jQuery('#ls-layers .ls-layer-box').each(function(layer) {

                    // Layer settings
                    jQuery(this).find('.ls-slide-options input, .ls-slide-options select').each(function() {
                      jQuery(this).attr('name', jQuery(this).data('name'));
                    });

                    // Sublayers
                    jQuery(this).find('.ls-sublayers > tr').each(function(sublayer) {
                      jQuery(this).find('input, select, textarea').each(function() {
                        jQuery(this).attr('name', jQuery(this).data('name'));
                      });
                    });
                  });

                  // Iterate over the callback functions
                  jQuery('.ls-callback-page textarea').each(function() {
                    jQuery(this).attr('name', jQuery(this).data('name'));
                  });

                  // Redirect the edit page when adding new slider
                  if(document.location.href.indexOf('add') != -1) {

                    // Redirect
                    document.location.href = drupal_base_path+'admin/layerslider/edit?id='+id+'';
                  }
                }
              }
            });
          });
        }, 500);
      },

      cloneFix : function() {

        jQuery('textarea').each(function() {
          jQuery(this).text( jQuery(this).val() );
        });

        // Select clone fix
        jQuery('select').each(function() {

          // Get selected index
          var index = jQuery(this).find('option:selected').index();

          // Deselect old options
          jQuery(this).find('option').attr('selected', false);

          // Select the new one
          jQuery(this).find('option').eq( index ).attr('selected', true);
        });
      }
    };

    jQuery(document).ready(function() {

    var drupal_base_path =  Drupal.settings.basePath;
    
    

      // List view
      if(
        document.location.href.indexOf('layerslider') != -1 &&
        document.location.href.indexOf('add') == -1 &&
        document.location.href.indexOf('edit') == -1 &&
        document.location.href.indexOf('skin-editor') == -1
        ) {

        // Slider remove
        jQuery('.ls-slider-list a.remove').click(function(e) {
          e.preventDefault();
          if(confirm('Are you sure you want to remove this slider?')){
            document.location.href = jQuery(this).attr('href');
          }
        });

      // Skin editor
      } else if(document.location.href.indexOf('skin-editor') != -1) {

        // Select
        jQuery('select[name="skin"]').change(function() {
          document.location.href = drupal_base_path+'admin/layerslider/skin-editor?skin=' + jQuery(this).children(':selected').val();
        });

        // Editor tab
        jQuery('#editor').keydown(function(e) {

          // Get button keycode
          var keyCode = e.keyCode || e.which;

          // Tab only
          if (keyCode == 9) {

            e.preventDefault();
            var start = jQuery(this).get(0).selectionStart;
            var end = jQuery(this).get(0).selectionEnd;

            // set textarea value to: text before caret + tab + text after caret
            jQuery(this).val(jQuery(this).val().substring(0, start)
              + "\t"
              + jQuery(this).val().substring(end));

            // put caret at right position again
            jQuery(this).get(0).selectionStart =
            jQuery(this).get(0).selectionEnd = start + 1;
          }
        });

      // Editor view
      } else {

        // Main tab bar page select
        jQuery('#ls-main-nav-bar a:not(.unselectable)').click(function(e) {
          e.preventDefault();
          LayerSlider.selectMainTab( this );
        });

        // Generate preview if user resizes the browser
        jQuery(window).resize(function(){
          LayerSlider.willGeneratePreview( jQuery('.ls-box.active').index() );
        });

        // Support menu
        jQuery('#ls-main-nav-bar a.support').click(function(e) {
          e.preventDefault();
          jQuery('#contextual-help-link').click();
        });

        // Settings: checkboxes
        jQuery('.ls-settings :checkbox').customCheckbox();

        // Generate preview
        jQuery(window).load(function() {
          LayerSlider.generatePreview( jQuery('.ls-box.active').index() );
        });

        // Uploads
        LayerSlider.openMediaLibrary();
        LayerSlider.insertUpload();

        // Settings: width, height
        jQuery('.ls-settings').find('input[name="width"], input[name="height", input[name="sublayercontainer"]').keyup(function() {
          LayerSlider.willGeneratePreview( jQuery('.ls-box.active').index() );
        });

        // Settings: backgroundColor
        jQuery('.ls-settings input[name="backgroundcolor"]').keyup(function() {
          LayerSlider.willGeneratePreview( jQuery('.ls-box.active').index() );
        });

        // Settings: reset button
        jQuery('.ls-reset').live('click', function() {

          // Empty field
          jQuery(this).prev().val('');

          // Generate preview
          LayerSlider.generatePreview( jQuery('.ls-box.active').index() );
        });

        // Settings: yourLogoStyle
        jQuery('.ls-settings input[name="yourlogostyle"]').keyup(function() {
          LayerSlider.willGeneratePreview( jQuery('.ls-box.active').index() );
        });

        // Add layer
        jQuery('#ls-add-layer').click(function(e) {
          e.preventDefault();
          LayerSlider.addLayer();
        });

        // Select layer
        jQuery('#ls-layer-tabs a:not(.unsortable)').live('click', function(e) {
          e.preventDefault();
          LayerSlider.selectLayer(this);
        });

        // Duplicate layer
        jQuery('.ls-layer-options-thead a.duplicate').live('click', function(e){
          e.preventDefault();
          LayerSlider.duplicateLayer(this);
        });

        // Add sublayer
        jQuery('.ls-add-sublayer').live('click', function(e) {
          e.preventDefault();
          LayerSlider.addSublayer(this);
        });

        // Remove layer
        jQuery('#ls-layer-tabs a span').live('click', function(e) {
          e.preventDefault();
          e.stopPropagation();
          LayerSlider.removeLayer(this);
        });

        // Select sublayer
        jQuery('.ls-sublayers tr').live('click', function() {
          LayerSlider.selectSubLayer(this);
        });


        // Sublayer pages
        jQuery('.ls-sublayer-nav a:not(:last-child)').live('click', function(e) {
          e.preventDefault();
          LayerSlider.selectSublayerPage(this);
        });

        // Remove sublayer
        jQuery('.ls-sublayer-nav a:last-child').live('click', function(e) {
          e.preventDefault();
          LayerSlider.removeSublayer(this);
        });

        // Duplicate sublayer
        jQuery('.ls-sublayer-options button.duplicate').live('click', function(e) {
          e.preventDefault();
          LayerSlider.duplicateSublayer(this);
        });

        // Highlight sublayer
        jQuery('.ls-highlight input').live('click', function(e) {
          e.stopPropagation();
          LayerSlider.highlightSublayer(this);
        });

        // Sublayer media type
        jQuery('.ls-sublayer-types > span').live('click', function(e) {
          e.preventDefault();
          LayerSlider.didSelectMediaType(this);
        });

        // Restore sublayer media type
        jQuery('.ls-sublayer-basic select').each(function() {

          // Get selected element
          var index = jQuery(this).find('option:selected').index();

          // Restore
          LayerSlider.selectMediaType(jQuery(this).parent().find('.ls-sublayer-types > span').eq(index));
        });

        // Sublayer: Style
        jQuery('.ls-sublayer-style input, .ls-sublayer-style select, .ls-sublayer-style textarea').live('keyup', function() {
          LayerSlider.willGeneratePreview( jQuery(this).closest('.ls-layer-box').index() );
        });

        // Sublayer: WordWrap
        jQuery('.ls-sublayers input[name="wordwrap"]').click(function() {
          LayerSlider.generatePreview( jQuery(this).closest('.ls-layer-box').index() );
        });

        // Sublayer: HTML
        jQuery('.ls-sublayers textarea[name="html"]').live('keyup', function() {
          LayerSlider.willGeneratePreview( jQuery(this).closest('.ls-layer-box').index() );
        });

        // Sublayer: sortables, draggable, etc
        LayerSlider.addSortables();
        LayerSlider.addDraggable();
        LayerSlider.addLayerSortables();

        // Sublayer: skip
        jQuery('.ls-sublayer-options input[name="skip"]').live('click', function() {
          LayerSlider.skipSublayer(this);
        });

        // Preview
        jQuery('.ls-preview-button').live('click', function(e) {
          e.preventDefault();
          LayerSlider.play( jQuery(this).closest('.ls-layer-box').index() );
        });

        // Preview drag element select
        jQuery('.draggable > *').live('click', function() {
          LayerSlider.selectDragElement(this);
        });

        // Save changes
        jQuery('#ls-slider-form').submit(function(e) {
          e.preventDefault();
          LayerSlider.save(this);
        });

        // Callback boxes
        LayerSlider.setCallbackBoxesWidth();
        jQuery(window).resize(function() {
          LayerSlider.setCallbackBoxesWidth();
        });

        // Color picker
        jQuery('.ls-colorpicker').each(function() {
          jQuery(this).farbtastic( function(color) {

            // Set color code in the input
            jQuery('.color').val(color);

            // Set input background
            jQuery('.color').css('background-color', color);

            // Update preview
            LayerSlider.willGeneratePreview( jQuery('.ls-box.active').index() );
          }).hide();
        });

        // Show color picker on focus
        jQuery('.color').focus(function() {
          jQuery(this).next().slideDown();
        });

        // Show color picker on blur
        jQuery('.color').blur(function() {
          jQuery(this).next().slideUp();
        });
      }

    });

  });
  
  
 
  
  


})(jQuery);

;
(function ($) {

/**
 * Attaches double-click behavior to toggle full path of Krumo elements.
 */
Drupal.behaviors.devel = {
  attach: function (context, settings) {

    // Add hint to footnote
    $('.krumo-footnote .krumo-call').once().before('<img style="vertical-align: middle;" title="Click to expand. Double-click to show path." src="' + settings.basePath + 'misc/help.png"/>');

    var krumo_name = [];
    var krumo_type = [];

    function krumo_traverse(el) {
      krumo_name.push($(el).html());
      krumo_type.push($(el).siblings('em').html().match(/\w*/)[0]);

      if ($(el).closest('.krumo-nest').length > 0) {
        krumo_traverse($(el).closest('.krumo-nest').prev().find('.krumo-name'));
      }
    }

    $('.krumo-child > div:first-child', context).dblclick(
      function(e) {
        if ($(this).find('> .krumo-php-path').length > 0) {
          // Remove path if shown.
          $(this).find('> .krumo-php-path').remove();
        }
        else {
          // Get elements.
          krumo_traverse($(this).find('> a.krumo-name'));

          // Create path.
          var krumo_path_string = '';
          for (var i = krumo_name.length - 1; i >= 0; --i) {
            // Start element.
            if ((krumo_name.length - 1) == i)
              krumo_path_string += '$' + krumo_name[i];

            if (typeof krumo_name[(i-1)] !== 'undefined') {
              if (krumo_type[i] == 'Array') {
                krumo_path_string += "[";
                if (!/^\d*$/.test(krumo_name[(i-1)]))
                  krumo_path_string += "'";
                krumo_path_string += krumo_name[(i-1)];
                if (!/^\d*$/.test(krumo_name[(i-1)]))
                  krumo_path_string += "'";
                krumo_path_string += "]";
              }
              if (krumo_type[i] == 'Object')
                krumo_path_string += '->' + krumo_name[(i-1)];
            }
          }
          $(this).append('<div class="krumo-php-path" style="font-family: Courier, monospace; font-weight: bold;">' + krumo_path_string + '</div>');

          // Reset arrays.
          krumo_name = [];
          krumo_type = [];
        }
      }
    );
  }
};

})(jQuery);
;
